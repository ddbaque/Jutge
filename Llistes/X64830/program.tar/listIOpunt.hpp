#include <iostream>
#include <list>
#include "Punt.hpp"

using namespace std;

ostream &operator<<(ostream &os, const list<Punt> &lp);
istream &operator>>(istream &is, list<Punt> &lp);
