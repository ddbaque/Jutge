#include <iostream>
#include <stack>
#include "Punt.hpp"

using namespace std;

ostream &operator<<(ostream &os, const stack<Punt> &p);

istream &operator>>(istream &is, stack<Punt> &p);
