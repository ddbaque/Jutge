#include <iostream>
#include <queue>
#include "Punt.hpp"

ostream &operator<<(ostream &os, const queue<Punt> &c);

istream &operator>>(istream &is, queue<Punt> &c);
